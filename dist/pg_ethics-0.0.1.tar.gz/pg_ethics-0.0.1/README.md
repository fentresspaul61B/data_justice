This package prints out a Data Ethics agreement to fill out while working on
your projects.

1. Call: **pip install Data_Justice**.
If in Jupyter or Colab, call **!pip install Data_Justice**.

2. Call from Data_Justice import generate_agreement

3. Call **generate_agreement()**.

4. Copy the agreement using cmd + "a", and paste it into a markdown cell.

5. Read through the agreement and fill it out.
